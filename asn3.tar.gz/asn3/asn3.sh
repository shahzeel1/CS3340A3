#!/bin/bash
javac *.java
java PrimMain $1

